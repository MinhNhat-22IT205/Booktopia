export default function Backdrop(props) {
  return <div onClick={props.onClose} className="backdrop"></div>;
}
