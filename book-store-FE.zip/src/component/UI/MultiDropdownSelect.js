import React, { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import XSVG from "../svg/XSVG";

const genres = [
  "Fiction",
  "Non-fiction",
  "Mystery",
  "Thriller",
  "Romance",
  "Science Fiction",
  "Fantasy",
  "Horror",
  "Historical Fiction",
  "Biography",
  "Autobiography",
  "Self-Help",
  "Business",
  "History",
  "Travel",
  "Cooking",
  "Young Adult",
  "Children",
  "Poetry",
  "Drama",
  "Comedy",
  "Action and Adventure",
  "Science",
  "Religion",
  "Philosophy",
  "Art",
  "Sports",
  "Parenting",
  "Education",
  "Health and Fitness",
  "Psychology",
  "Technology",
  "Reference",
  "Graphic Novels",
  "Comics",
  "Magazines",
  "Short Stories",
  "Essays",
  "Anthology",
  "Classic",
  "Historical",
  "Contemporary",
  "Literary Fiction",
  "Crime",
  "Dystopian",
  "Urban Fantasy",
  "Paranormal",
  "Supernatural",
  "Psychological Thriller",
  "Political",
  "Science",
  "Space Opera",
  "Cyberpunk",
  "Post-Apocalyptic",
  "Steampunk",
  "Western",
  "Magical Realism",
  "Gothic",
  "Time Travel",
  "Chick Lit",
  "Urban Fiction",
  "Satire",
  "Humor",
  "Memoir",
  "True Crime",
  "Travelogue",
  "Artificial Intelligence",
  "Environmental",
  "Sociology",
  "Economics",
  "Anthropology",
  "Philosophy of Mind",
  "Spirituality",
  "Mythology",
  "Fairy Tales",
  "Graphic Design",
  "Crafts and Hobbies",
  "Fashion",
  "Sports Memoir",
  "Fitness",
  "Nutrition",
  "Cognitive Science",
  "Computer Science",
  "Data Science",
  "Software Development",
  "Web Development",
];
function MuliDropdownSelect({
  label,
  errors,
  type,
  name,
  setData,
  initialValue = [],
  ...otherProps
}) {
  const [input, setInput] = useState(initialValue);
  const [searchValue, setSearchValue] = useState("");
  const [initial, setInitial] = useState(true);
  const [open, setOpen] = useState(false);
  const ref = useRef();

  useEffect(() => {
    document.addEventListener("mousedown", (e) => {
      if (ref.current && !ref.current.contains(e.target)) {
        setOpen(false);
      }
    });
  }, []);
  useEffect(() => {
    console.log(input);
    setData(name, input);
  }, [input, name, setData]);
  function blur(e) {
    console.log("blur");
    setInitial(false);
  }
  const inputProps = {
    id: name,
    name,
    onBlur: blur,
    type,
    ...otherProps,
    style: {
      borderColor: `${errors[name] && initial === false ? "red" : "black"}`,
      outline: "none",
    },
  };
  const addNewItem = (item) => {
    setInput((prev) => [...prev, item]);
  };
  const handleDelete = (i) => {
    const inputValue = [...input];
    inputValue.splice(i, 1);
    setInput(inputValue);
    setData(name, inputValue);
  };
  return (
    <>
      <div className="flex gap-5">
        <label htmlFor={name} className="font-semibold ">
          {label}
        </label>
      </div>
      <div
        onClick={() => {
          blur();
          setOpen(true);
        }}
        className="flex flex-wrap items-center gap-2 p-1.5 border rounded-lg min-h-[40px]"
      >
        {input.map((item, index) => (
          <div
            onClick={() => handleDelete(index)}
            className="flex cursor-pointer items-center gap-1 bg-gray-200 px-2 py-0.5 rounded-md"
          >
            <p className="text-gray-600 h-fit">{item}</p>
            <button type="button" className="text-gray-600">
              <XSVG />
            </button>
          </div>
        ))}
      </div>
      {open && (
        <div ref={ref} className="border rounded-md w-full mt-2 shadow-md">
          <div className="m-1.5">
            <input
              placeholder="Click here to search..."
              type="text"
              onChange={(e) => setSearchValue(e.target.value)}
              value={searchValue}
              className=" border rounded-sm w-full px-2 py-1 focus:ring focus:outline-none"
            />
          </div>

          <hr />
          <div className="w-full max-h-[300px] overflow-y-scroll">
            {genres.map((item, index) => {
              if (
                !input.includes(item) &&
                item.toLowerCase().includes(searchValue.toLowerCase())
              ) {
                return (
                  <div
                    className="w-full px-4 py-1 hover:bg-gray-200 cursor-pointer"
                    onClick={() => addNewItem(item)}
                  >
                    {item}
                  </div>
                );
              } else return <></>;
            })}
          </div>
        </div>
      )}

      {errors[name] && initial === false && (
        <p className="text-red-600 ml-[16px]">{errors[name]}</p>
      )}
    </>
  );
}
export default React.memo(MuliDropdownSelect);
