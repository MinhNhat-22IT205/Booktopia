import React, { useState } from "react";
import OrderItem from "./OrderItem";
import Modal from "../UI/Modal";

export default function Order({ order, index }) {
  const [viewDetail, setViewDetail] = useState(false);
  const exitView = () => {
    setViewDetail(false);
  };

  return (
    <div key={order.id}>
      <div className="rounded-xl px-6 py-6 shadow-lg shadow-[#000]/20 border w-[335px]">
        <div>
          <h1 className="font-bold text-xl">Order #{index + 1}</h1>
          <h1 className="font-bold text-[#000]/40 text-md">
            {new Date(order.checkOutDate).toLocaleString("en-US", {
              day: "numeric",
              month: "short",
              hour: "numeric",
              minute: "numeric",
              hour12: true,
            })}
          </h1>
        </div>
        <div className="mt-4 max-h-[250px] overflow-y-auto">
          {order.items.map((item) => {
            return <OrderItem item={item} />;
          })}
        </div>
        <div className="flex items-center justify-between my-2">
          <div>
            <h2 className="text-[#000]/40 font-semibold text-md">
              {`x${order.items.reduce((total, item) => {
                return total + item.quantity;
              }, 0)} items`}
            </h2>
            <h1 className="font-bold text-xl">
              ${order.totalAmount.toFixed(2)}
            </h1>
          </div>
          <button
            onClick={() => setViewDetail(true)}
            className="border-2 border-[#efedfd] rounded-xl py-2.5 px-4 font-bold text-[#6353d1] hover:bg-[#d4d0fe] hover:border-[#d4d0fe]"
          >
            View Detail
          </button>
        </div>
      </div>

      {viewDetail && (
        <Modal onClose={exitView}>
          <div className=" flex gap-5 w-full">
            <div className="w-full basis-2/3">
              <table className="w-full  rounded-xl overflow-hidden ">
                <thead className="text-left bg-[#6c5dd4] text-white ">
                  <tr className="shadow-inner shadow-[#a298ff] rounded-t-xl overflow-hidden">
                    <th className="pl-32 py-2 text-lg">Product</th>
                    <th className="py-2 text-lg">Unit Price</th>
                    <th className="py-2 text-lg">Quantity</th>
                    <th className="py-2 text-lg">Total</th>
                    <th className="py-2 text-lg">Status</th>
                  </tr>
                </thead>
                <tbody className="w-fit [&>*]:px-5 border-2 border-t-0 [&>*]:py-2">
                  {order.items.map((item) => {
                    return (
                      <tr key={item.id}>
                        <td className="flex items-center gap-5">
                          <img
                            src={"http://localhost:5000/" + item.book.image}
                            alt=""
                            className="w-24 h-32 object-cover rounded-lg my-3 ml-5"
                          />
                          <div>
                            <h2 className="font-bold text-xl text-primaryColor">
                              {item.book.title}
                            </h2>
                            <p className="text-[#000]/50 font-semibold">
                              by{" "}
                              <span className="font-bold text-[#6353d1]/80">
                                {item.book.author}
                              </span>
                            </p>
                          </div>
                        </td>
                        <td className="font-semibold text-center text-lg text-secondaryColor top-0">
                          $
                          {(
                            item.book.price -
                            (item.book.price * item.book.discount) / 100
                          ).toFixed(2)}
                        </td>
                        <td>
                          <div className="text-center w-20">
                            {item.quantity}
                          </div>
                        </td>
                        <td className="text-[#6c5dd4] text-lg font-semibold">
                          $
                          {(
                            (item.book.price -
                              (item.book.price * item.book.discount) / 100) *
                            item.quantity
                          ).toFixed(2)}
                        </td>
                        <td>
                          <div className="text-center w-20">{item.status}</div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className="flex flex-col items-start justify-start w-fit rounded-xl bg-gray-50 px-5">
              <div className=" w-fit  mt-5">
                <h1 className="uppercase ml-4 font-bold text-xl my-auto before:content-[''] before:absolute before:w-[4px] before:rounded-full before:h-full relative before:top-0 before:-left-4 before:bg-[#6353d1] mt-1 mb-3">
                  shipping detail
                </h1>
                <table>
                  <tbody>
                    <tr className="[&>*]:border [&>*]:px-5 [&>*]:py-2">
                      <td className="text-left font-semibold">Receiver</td>
                      <td>{order.receiverName}</td>
                    </tr>
                    <tr className="[&>*]:border [&>*]:px-5 [&>*]:py-2">
                      <td className="text-left font-semibold">
                        Shipping Address
                      </td>
                      <td>{order.deliveryAddress}</td>
                    </tr>
                    <tr className="[&>*]:border [&>*]:px-5 [&>*]:py-2">
                      <td className="text-left font-semibold">Country</td>
                      <td>{"order.country"}</td>
                    </tr>
                    <tr className="[&>*]:border [&>*]:px-5 [&>*]:py-2">
                      <td className="text-left font-semibold">Status</td>
                      <td className="text-[#22c55e] font-semibold">
                        {order.orderStatus}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className=" w-fit mt-5">
                <h1 className="uppercase ml-4 font-bold text-xl my-auto before:content-[''] before:absolute before:w-[4px] before:rounded-full before:h-full relative before:top-0 before:-left-4 before:bg-[#6353d1] mt-1 mb-3">
                  Cart Subtotal
                </h1>
                <table>
                  <tbody>
                    <tr className="[&>*]:border [&>*]:px-5 [&>*]:py-2">
                      <td className="text-left font-semibold">
                        Order Subtotal
                      </td>
                      <td>${order.totalAmount.toFixed(2)}</td>
                    </tr>
                    <tr className="[&>*]:border [&>*]:px-5 [&>*]:py-2">
                      <td className="text-left font-semibold">Shipping</td>
                      <td>Free Shipping</td>
                    </tr>
                    <tr className="[&>*]:border [&>*]:px-5 [&>*]:py-2">
                      <td className="text-left font-semibold">Coupon</td>
                      <td>$0.00</td>
                    </tr>
                    <tr className="[&>*]:border [&>*]:px-5 [&>*]:py-2">
                      <td className="text-left !font-semibold">Total</td>
                      <td>${order.totalAmount.toFixed(2)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
