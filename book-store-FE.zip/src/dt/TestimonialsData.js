let testimonialData = [
  {
    id: "c1",
    star: 4,
    comment:
      "Very impresive store. Your book made studying for the ABC certification exams a breeze. Thank you very much",
    link: "https://bookland.dexignzone.com/xhtml/images/testimonial/testimonial4.jpg",
    name: "Angela Moss",
  },
  {
    id: "c2",
    star: 3,
    comment:
      "Very impresive store. Your book made studying for the ABC certification exams a breeze. Thank you very much",
    link: "https://bookland.dexignzone.com/xhtml/images/testimonial/testimonial1.jpg",
    name: "Jason Huong",
  },
  {
    id: "c3",
    star: 5,
    comment:
      "Very impresive store. Your book made studying for the ABC certification exams a breeze. Thank you very much",
    link: "https://bookland.dexignzone.com/xhtml/images/testimonial/testimonial3.jpg",
    name: "Steve Henry",
  },
  {
    id: "c4",
    star: 3,
    comment:
      "Very impresive store. Your book made studying for the ABC certification exams a breeze. Thank you very much",
    link: "https://bookland.dexignzone.com/xhtml/images/testimonial/testimonial2.jpg",
    name: "Miranda Lee",
  },
];
export default testimonialData;
